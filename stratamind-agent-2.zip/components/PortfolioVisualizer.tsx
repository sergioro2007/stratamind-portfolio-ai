import React, { useState, useMemo, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { PortfolioSlice, SliceType } from '../types';
import { ChevronRight, Folder, TrendingUp, DollarSign, Plus, Trash2, X } from 'lucide-react';

interface Props {
    rootSlice: PortfolioSlice;
    totalValue: number;
    onAddSlice?: (parentId: string, type: SliceType, name: string, symbol: string | undefined, allocation: number) => void;
    onRemoveSlice?: (sliceId: string) => void;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1'];

const PortfolioVisualizer: React.FC<Props> = ({ rootSlice, totalValue, onAddSlice, onRemoveSlice }) => {
    const [path, setPath] = useState<PortfolioSlice[]>([rootSlice]);
    const currentView = path[path.length - 1];

    // Add Slice Modal State
    const [showAddModal, setShowAddModal] = useState(false);
    const [newSliceType, setNewSliceType] = useState<SliceType>(SliceType.HOLDING);
    const [newName, setNewName] = useState('');
    const [newSymbol, setNewSymbol] = useState('');
    const [newAllocation, setNewAllocation] = useState(0);

    // Reset path if root changes significantly (e.g. new portfolio created)
    useEffect(() => {
        // If the current path is invalid (e.g. deleted), reset to root
        // For now, just reset on root ID change
        if (rootSlice.id !== path[0].id) {
            setPath([rootSlice]);
        } else {
             // If we are deep in the tree, we need to make sure the path objects are up to date with the latest rootSlice data
             // This requires re-traversing or finding the node in the new tree.
             // Simplification: We will just try to update the current view reference if possible, otherwise reset.
             const refreshPath = (currentPath: PortfolioSlice[], currentRoot: PortfolioSlice): PortfolioSlice[] | null => {
                if (currentPath.length === 0) return [];
                if (currentPath[0].id !== currentRoot.id) return null; // Root mismatch
                
                const newPath = [currentRoot];
                let pointer = currentRoot;
                
                for (let i = 1; i < currentPath.length; i++) {
                    const nextId = currentPath[i].id;
                    const found = pointer.children?.find(c => c.id === nextId);
                    if (found) {
                        newPath.push(found);
                        pointer = found;
                    } else {
                        // Path broken
                        return [currentRoot]; 
                    }
                }
                return newPath;
             };
             
             const updatedPath = refreshPath(path, rootSlice);
             if (updatedPath) setPath(updatedPath);
        }
    }, [rootSlice]); 

    const data = useMemo(() => {
        if (!currentView.children) return [];
        return currentView.children.map(child => ({
            name: child.name,
            value: child.targetAllocation,
            type: child.type,
            raw: child
        }));
    }, [currentView]);

    const handleSliceClick = (entry: any) => {
        if (entry.raw.type === SliceType.GROUP) {
            setPath([...path, entry.raw]);
        }
    };

    const handleBreadcrumbClick = (index: number) => {
        setPath(path.slice(0, index + 1));
    };

    const handleAddSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (onAddSlice && newName && newAllocation > 0) {
            onAddSlice(currentView.id, newSliceType, newName, newSymbol || undefined, Number(newAllocation));
            setShowAddModal(false);
            setNewName('');
            setNewSymbol('');
            setNewAllocation(0);
        }
    };

    const handleDelete = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (onRemoveSlice && confirm('Are you sure you want to remove this slice?')) {
            onRemoveSlice(id);
        }
    }

    const CustomTooltip = ({ active, payload }: any) => {
        if (active && payload && payload.length) {
            const data = payload[0].payload;
            return (
                <div className="bg-slate-800 border border-slate-700 p-2 rounded shadow-xl text-xs">
                    <p className="font-bold text-slate-200">{data.name}</p>
                    <p className="text-slate-400">Target: {data.value}%</p>
                    <p className="text-emerald-400">Est. Value: ${((totalValue * (data.value / 100))).toLocaleString()}</p>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="flex flex-col h-full bg-slate-800 rounded-xl border border-slate-700 overflow-hidden relative">
            {/* Header / Breadcrumbs */}
            <div className="p-4 border-b border-slate-700 bg-slate-900/50 flex items-center justify-between">
                <div className="flex items-center space-x-2 overflow-x-auto">
                    {path.map((slice, index) => (
                        <div key={slice.id} className="flex items-center text-sm shrink-0">
                            {index > 0 && <ChevronRight className="w-4 h-4 text-slate-500 mx-1" />}
                            <button
                                onClick={() => handleBreadcrumbClick(index)}
                                className={`flex items-center px-2 py-1 rounded hover:bg-slate-700 transition-colors ${
                                    index === path.length - 1 ? 'text-white font-semibold' : 'text-slate-400'
                                }`}
                            >
                                {slice.type === SliceType.GROUP ? <Folder className="w-3 h-3 mr-1" /> : <TrendingUp className="w-3 h-3 mr-1"/>}
                                {slice.name}
                            </button>
                        </div>
                    ))}
                </div>
                {currentView.type === SliceType.GROUP && (
                     <button 
                        onClick={() => setShowAddModal(true)}
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded shadow-lg transition-colors flex items-center gap-1 text-xs font-medium px-3"
                    >
                        <Plus className="w-3 h-3" /> Add Slice
                    </button>
                )}
            </div>

            {/* Content Area */}
            <div className="flex-1 flex flex-col md:flex-row p-4 gap-6 relative z-0">
                
                {/* Chart */}
                <div className="flex-1 min-h-[300px] relative">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={data}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={100}
                                paddingAngle={5}
                                dataKey="value"
                                onClick={handleSliceClick}
                                cursor="pointer"
                                stroke="none"
                            >
                                {data.map((entry, index) => (
                                    <Cell 
                                        key={`cell-${index}`} 
                                        fill={COLORS[index % COLORS.length]} 
                                        className="hover:opacity-80 transition-opacity outline-none"
                                    />
                                ))}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                            <Legend 
                                verticalAlign="bottom" 
                                height={36} 
                                formatter={(value, entry: any) => <span className="text-slate-300 ml-1">{value}</span>}
                            />
                        </PieChart>
                    </ResponsiveContainer>
                    {/* Center Label */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="text-center">
                            <span className="text-xs text-slate-400 block">Total</span>
                            <span className="text-lg font-bold text-white">100%</span>
                        </div>
                    </div>
                </div>

                {/* List Details */}
                <div className="flex-1 overflow-y-auto pr-2 max-h-[300px] scrollbar-hide">
                    <h3 className="text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider flex justify-between">
                        <span>Allocation Breakdown</span>
                        <span className="text-xs normal-case opacity-50">Click items to drill down</span>
                    </h3>
                    <div className="space-y-2">
                        {data.map((item, idx) => (
                            <div 
                                key={idx}
                                onClick={() => handleSliceClick({raw: item.raw})}
                                className="group flex items-center justify-between p-3 bg-slate-700/50 hover:bg-slate-700 rounded-lg cursor-pointer border border-transparent hover:border-slate-600 transition-all relative"
                            >
                                <div className="flex items-center">
                                    <div 
                                        className="w-3 h-3 rounded-full mr-3" 
                                        style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                                    />
                                    <div>
                                        <p className="text-sm font-medium text-white">{item.name}</p>
                                        <p className="text-xs text-slate-400">{item.raw.type === SliceType.GROUP ? 'Group' : item.raw.symbol || 'Holding'}</p>
                                    </div>
                                </div>
                                <div className="text-right flex items-center gap-4">
                                    <div>
                                        <p className="text-sm font-bold text-white">{item.value}%</p>
                                        <p className="text-xs text-emerald-400 flex items-center justify-end">
                                            <DollarSign className="w-3 h-3" />
                                            {((totalValue * (item.value / 100))).toLocaleString()}
                                        </p>
                                    </div>
                                    <button 
                                        onClick={(e) => handleDelete(e, item.raw.id)}
                                        className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-400/10 rounded transition-colors"
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        ))}
                        {data.length === 0 && (
                            <div className="text-center p-8 text-slate-500 border border-dashed border-slate-700 rounded-lg">
                                Empty Group. Add a slice to get started.
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Add Slice Modal Overlay */}
            {showAddModal && (
                <div className="absolute inset-0 bg-slate-900/90 z-20 flex items-center justify-center p-4 backdrop-blur-sm">
                    <div className="bg-slate-800 border border-slate-700 w-full max-w-sm rounded-xl shadow-2xl p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-white">Add New Slice</h3>
                            <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white"><X className="w-5 h-5"/></button>
                        </div>
                        <form onSubmit={handleAddSubmit} className="space-y-4">
                            <div>
                                <label className="block text-xs font-semibold text-slate-400 mb-1">Type</label>
                                <div className="flex bg-slate-700 p-1 rounded-lg">
                                    <button 
                                        type="button" 
                                        onClick={() => setNewSliceType(SliceType.HOLDING)}
                                        className={`flex-1 text-sm py-1.5 rounded-md transition-colors ${newSliceType === SliceType.HOLDING ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
                                    >
                                        Holding
                                    </button>
                                    <button 
                                        type="button" 
                                        onClick={() => setNewSliceType(SliceType.GROUP)}
                                        className={`flex-1 text-sm py-1.5 rounded-md transition-colors ${newSliceType === SliceType.GROUP ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
                                    >
                                        Group
                                    </button>
                                </div>
                            </div>
                            
                            <div>
                                <label className="block text-xs font-semibold text-slate-400 mb-1">Name</label>
                                <input 
                                    type="text" 
                                    value={newName}
                                    onChange={(e) => setNewName(e.target.value)}
                                    placeholder={newSliceType === SliceType.GROUP ? "e.g. Tech Sector" : "e.g. Apple Inc"}
                                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-indigo-500 focus:outline-none"
                                    required
                                />
                            </div>

                            {newSliceType === SliceType.HOLDING && (
                                <div>
                                    <label className="block text-xs font-semibold text-slate-400 mb-1">Ticker Symbol</label>
                                    <input 
                                        type="text" 
                                        value={newSymbol}
                                        onChange={(e) => setNewSymbol(e.target.value.toUpperCase())}
                                        placeholder="e.g. AAPL"
                                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-indigo-500 focus:outline-none font-mono"
                                        required
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-xs font-semibold text-slate-400 mb-1">Target Allocation (%)</label>
                                <input 
                                    type="number" 
                                    min="1" max="100"
                                    value={newAllocation}
                                    onChange={(e) => setNewAllocation(Number(e.target.value))}
                                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-indigo-500 focus:outline-none"
                                    required
                                />
                                <p className="text-[10px] text-slate-500 mt-1">Remaining allocation will be adjusted automatically or flagged.</p>
                            </div>

                            <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-lg transition-colors mt-2">
                                Add Slice
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PortfolioVisualizer;