import React, { useState, useEffect, useRef, useMemo } from 'react';
import { LayoutDashboard, Wallet, TrendingUp, Settings, Activity, Building2, ChevronDown, ChevronRight, PlusCircle, CreditCard, Trash2, Plus } from 'lucide-react';
import { Institution, Account, SliceType, Message, Sender, AIProposal, PortfolioSlice } from './types';
import PortfolioVisualizer from './components/PortfolioVisualizer';
import ChatPanel from './components/ChatPanel';
import { startChatSession } from './services/geminiService';
import { db, generateId } from './services/database';
import { Chat } from '@google/genai';

const App: React.FC = () => {
    // Application State
    const [institutions, setInstitutions] = useState<Institution[]>([]);
    const [selectedInstId, setSelectedInstId] = useState<string | null>(null);
    const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
    const [collapsedInsts, setCollapsedInsts] = useState<Set<string>>(new Set());

    const [messages, setMessages] = useState<Message[]>([
        { 
            id: 'welcome', 
            sender: Sender.AI, 
            text: "Hello! I'm StrataMind. Select an account to start managing your strategy.", 
            timestamp: new Date() 
        }
    ]);
    const [isTyping, setIsTyping] = useState(false);
    const [pendingProposal, setPendingProposal] = useState<AIProposal | null>(null);
    const chatSessionRef = useRef<Chat | null>(null);

    // Load Data on Mount
    useEffect(() => {
        const data = db.load();
        setInstitutions(data);
        if (data.length > 0) {
            setSelectedInstId(data[0].id);
            if (data[0].accounts.length > 0) {
                setSelectedAccountId(data[0].accounts[0].id);
            }
        }
    }, []);

    // Derived State
    const activeInstitution = institutions.find(i => i.id === selectedInstId);
    const activeAccount = activeInstitution?.accounts.find(a => a.id === selectedAccountId);
    
    // Calculate Global Totals
    const globalNetWorth = useMemo(() => {
        return institutions.reduce((total, inst) => {
            return total + inst.accounts.reduce((accTotal, acc) => accTotal + acc.totalValue, 0);
        }, 0);
    }, [institutions]);

    useEffect(() => {
        chatSessionRef.current = startChatSession();
    }, []);

    const addToChat = (text: string, sender: Sender, toolName?: string) => {
        setMessages(prev => [...prev, {
            id: generateId(),
            sender,
            text,
            timestamp: new Date(),
            toolName
        }]);
    };

    // --- Navigation Helpers ---
    
    const toggleCollapse = (instId: string) => {
        const newSet = new Set(collapsedInsts);
        if (newSet.has(instId)) newSet.delete(instId);
        else newSet.add(instId);
        setCollapsedInsts(newSet);
    };

    // --- CRUD Operations ---

    const handleAddInstitution = () => {
        const name = window.prompt("Enter Institution Name (e.g., Schwab, Robinhood):");
        if (name) {
            setInstitutions(prev => db.createInstitution(name, prev));
        }
    };

    const handleDeleteInstitution = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (window.confirm("Are you sure you want to delete this Institution and all its accounts?")) {
            setInstitutions(prev => {
                const updated = db.deleteInstitution(id, prev);
                return updated;
            });
            if (selectedInstId === id) {
                setSelectedInstId(null);
                setSelectedAccountId(null);
            }
        }
    };

    const handleAddAccount = (e: React.MouseEvent, instId: string) => {
        // Prevent event from bubbling up (if any parent handlers existed, though none block this currently)
        e.stopPropagation();
        const name = window.prompt("Enter Account Name (e.g., Roth IRA):");
        if (name) {
            const type = window.prompt("Enter Account Type (e.g., Retirement, Taxable):") || "General";
            setInstitutions(prev => db.createAccount(instId, name, type, prev));
        }
    };

    const handleDeleteAccount = (e: React.MouseEvent, instId: string, accId: string) => {
        e.stopPropagation();
        if (window.confirm("Delete this account?")) {
            setInstitutions(prev => db.deleteAccount(instId, accId, prev));
            if (selectedAccountId === accId) setSelectedAccountId(null);
        }
    };

    // --- Portfolio Logic Helpers (Immutable Updates + Persistence) ---

    const updateActiveAccount = (newAccountData: Partial<Account>) => {
        if (!selectedInstId || !selectedAccountId) return;

        setInstitutions(prevInsts => {
            const updatedInstitutions = prevInsts.map(inst => {
                if (inst.id !== selectedInstId) return inst;
                return {
                    ...inst,
                    accounts: inst.accounts.map(acc => {
                        if (acc.id !== selectedAccountId) return acc;
                        return { ...acc, ...newAccountData };
                    })
                };
            });
            db.save(updatedInstitutions);
            return updatedInstitutions;
        });
    };

    const findGroupByName = (root: PortfolioSlice, name: string): PortfolioSlice | null => {
        if (root.name.toLowerCase().includes(name.toLowerCase()) && root.type === SliceType.GROUP) return root;
        if (root.children) {
            for (const child of root.children) {
                const found = findGroupByName(child, name);
                if (found) return found;
            }
        }
        return null;
    };

    // --- Recursive Tree Helpers with Normalization ---

    const normalizeChildren = (children: PortfolioSlice[]) => {
        if (children.length === 0) return;
        const total = children.reduce((sum, c) => sum + c.targetAllocation, 0);
        if (total === 0) return;
        
        // If total is close to 100 (floating point tolerance), no need to act
        if (Math.abs(total - 100) < 0.1) return;

        const factor = 100 / total;
        children.forEach(c => {
            c.targetAllocation = Math.round(c.targetAllocation * factor * 10) / 10;
        });
        
        // Adjust rounding error on the largest slice
        const newTotal = children.reduce((sum, c) => sum + c.targetAllocation, 0);
        const diff = 100 - newTotal;
        if (Math.abs(diff) > 0) {
            const largest = children.reduce((prev, current) => (prev.targetAllocation > current.targetAllocation) ? prev : current);
            largest.targetAllocation = Number((largest.targetAllocation + diff).toFixed(1));
        }
    };

    const addNodeToTree = (node: PortfolioSlice, parentId: string, newNode: PortfolioSlice): boolean => {
        if (node.id === parentId) {
            if (!node.children) node.children = [];
            
            // Logic: Reduce existing allocations to make room for new one
            // New allocation is fixed (newNode.targetAllocation). 
            // Existing ones scale to fit (100 - newNode.targetAllocation).
            const incomingAlloc = newNode.targetAllocation;
            if (node.children.length > 0 && incomingAlloc < 100) {
                const remainingSpace = 100 - incomingAlloc;
                // Currently existing sum
                const currentSum = node.children.reduce((s, c) => s + c.targetAllocation, 0);
                if (currentSum > 0) {
                    const scaleFactor = remainingSpace / currentSum;
                    node.children.forEach(c => {
                         c.targetAllocation = Math.floor(c.targetAllocation * scaleFactor);
                    });
                }
            } else if (node.children.length > 0 && incomingAlloc >= 100) {
                // If new one takes 100%, everything else goes to 0 (simplified)
                node.children.forEach(c => c.targetAllocation = 0);
            }

            node.children.push(newNode);
            normalizeChildren(node.children); // Ensure clean 100%
            return true;
        }
        if (node.children) {
            for (const child of node.children) {
                if (addNodeToTree(child, parentId, newNode)) return true;
            }
        }
        return false;
    };

    const removeNodeFromTree = (node: PortfolioSlice, nodeId: string): boolean => {
        if (!node.children) return false;
        const idx = node.children.findIndex(c => c.id === nodeId);
        if (idx !== -1) {
            node.children.splice(idx, 1);
            normalizeChildren(node.children); // Scale remaining up to 100%
            return true;
        }
        for (const child of node.children) {
            if (removeNodeFromTree(child, nodeId)) return true;
        }
        return false;
    };

    // --- Manual Portfolio Interactions ---

    const handleManualAddSlice = (parentId: string, type: SliceType, name: string, symbol: string | undefined, allocation: number) => {
        if (!activeAccount) return;
        
        const newRoot = JSON.parse(JSON.stringify(activeAccount.root));
        const newSlice: PortfolioSlice = {
            id: generateId(),
            parentId,
            type,
            name,
            symbol,
            targetAllocation: allocation,
            currentValue: 0, 
            children: type === SliceType.GROUP ? [] : undefined
        };

        if (addNodeToTree(newRoot, parentId, newSlice)) {
            updateActiveAccount({ root: newRoot });
        } else {
            alert("Could not find parent group.");
        }
    };

    const handleManualRemoveSlice = (sliceId: string) => {
        if (!activeAccount) return;
        
        const newRoot = JSON.parse(JSON.stringify(activeAccount.root));
        // Prevent deleting root
        if (newRoot.id === sliceId) {
            alert("Cannot delete the root strategy.");
            return;
        }

        if (removeNodeFromTree(newRoot, sliceId)) {
            updateActiveAccount({ root: newRoot });
        } else {
            alert("Could not find slice to remove.");
        }
    };

    const performRebalance = () => {
        if (!activeAccount) return;
        // In a real app, this would generate trade orders.
        // Here, we simulate a "perfect rebalance" where currentValue becomes exactly the target % of totalValue.
        const newRoot = JSON.parse(JSON.stringify(activeAccount.root));
        
        const redistributeValues = (node: PortfolioSlice, parentVal: number) => {
            node.currentValue = parentVal;
            if (node.children) {
                node.children.forEach(child => {
                     const childVal = parentVal * (child.targetAllocation / 100);
                     redistributeValues(child, childVal);
                });
            }
        };

        redistributeValues(newRoot, activeAccount.totalValue);
        updateActiveAccount({ root: newRoot });
        return true;
    };

    // --- AI Logic Execution ---

    const addTickerToGroup = (groupName: string, ticker: string, alloc: number) => {
        if (!activeAccount) return;
        
        const newRoot = JSON.parse(JSON.stringify(activeAccount.root));
        const targetGroup = findGroupByName(newRoot, groupName) || newRoot;

        if (targetGroup.children) {
            // Use same adding logic as manual to ensure normalization
            const newSlice = {
                id: generateId(),
                parentId: targetGroup.id,
                type: SliceType.HOLDING,
                name: ticker,
                symbol: ticker,
                targetAllocation: alloc,
                currentValue: 0
            };
            
            // Re-use logic for scaling
            const incomingAlloc = alloc;
            if (targetGroup.children.length > 0) {
                 const remainingSpace = 100 - incomingAlloc;
                 const currentSum = targetGroup.children.reduce((s: number, c: PortfolioSlice) => s + c.targetAllocation, 0);
                 if (currentSum > 0) {
                     const scaleFactor = remainingSpace / currentSum;
                     targetGroup.children.forEach((c: PortfolioSlice) => {
                          c.targetAllocation = Math.floor(c.targetAllocation * scaleFactor);
                     });
                 }
            }

            targetGroup.children.push(newSlice);
            normalizeChildren(targetGroup.children);
        }

        updateActiveAccount({ root: newRoot });
    };

    const createNewStrategy = (strategyName: string, groups: any[]) => {
        if (!activeAccount) return;

        const rootId = generateId();
        // If account has 0 value, assume we're funding it with 10k mock data for demo
        const totalVal = activeAccount.totalValue === 0 ? 10000 : activeAccount.totalValue;

        const newChildren = groups.map((g: any) => {
            const groupValue = totalVal * (g.allocation / 100);
            
            let groupChildren: PortfolioSlice[] = [];
            if (g.tickers && Array.isArray(g.tickers) && g.tickers.length > 0) {
                const tickerAlloc = 100 / g.tickers.length;
                groupChildren = g.tickers.map((t: string) => ({
                    id: generateId(),
                    parentId: 'temp', 
                    type: SliceType.HOLDING,
                    name: t,
                    symbol: t,
                    targetAllocation: tickerAlloc,
                    currentValue: groupValue * (tickerAlloc / 100)
                }));
            }

            return {
                id: generateId(),
                parentId: rootId,
                type: SliceType.GROUP,
                name: g.name,
                targetAllocation: g.allocation,
                currentValue: groupValue,
                children: groupChildren
            };
        });

        // Fix parentIds
        newChildren.forEach((g: PortfolioSlice) => {
            g.children?.forEach(c => c.parentId = g.id);
        });

        const newRoot: PortfolioSlice = {
            id: rootId,
            parentId: null,
            type: SliceType.GROUP,
            name: strategyName,
            targetAllocation: 100,
            currentValue: totalVal,
            children: newChildren
        };

        // Also update total value if it was 0
        updateActiveAccount({ root: newRoot, totalValue: totalVal });
    };

    // --- Interaction Logic ---

    const handleSendMessage = async (text: string) => {
        if (!activeAccount) {
            addToChat("Please select a specific account from the sidebar first.", Sender.SYSTEM);
            return;
        }

        addToChat(text, Sender.USER);
        setIsTyping(true);

        try {
            if (!chatSessionRef.current) return;

            const contextText = `[Context: User is viewing Account "${activeAccount.name}" in Institution "${activeInstitution?.name}". Total Value: $${activeAccount.totalValue}] ${text}`;

            const response = await chatSessionRef.current.sendMessage({ message: contextText });
            const result = response; 
            
            const functionCalls = result.functionCalls;

            if (functionCalls && functionCalls.length > 0) {
                const call = functionCalls[0];
                const args = call.args as any;

                let proposal: AIProposal | null = null;
                let description = '';

                switch (call.name) {
                    case 'create_portfolio_structure':
                        const groupCount = args.groups.length;
                        description = `Initialize "${args.strategyName}" for ${activeAccount.name}.`;
                        proposal = { id: call.id, type: 'CREATE_PORTFOLIO', description, details: args, status: 'PENDING', toolName: call.name };
                        break;
                    case 'add_ticker_to_group':
                        description = `Add ${args.symbol} to ${args.groupName || 'Root'} in ${activeAccount.name}.`;
                        proposal = { id: call.id, type: 'ADD_SLICE', description, details: args, status: 'PENDING', toolName: call.name };
                        break;
                    case 'rebalance_portfolio':
                        description = `Rebalance ${activeAccount.name} to align current values with targets.`;
                        proposal = { id: call.id, type: 'REBALANCE', description, details: { method: 'Threshold' }, status: 'PENDING', toolName: call.name };
                        break;
                    case 'analyze_market_sentiment':
                        addToChat(`Analyzing market data for ${args.sectors.join(', ')}...`, Sender.SYSTEM);
                         const marketResponse = await chatSessionRef.current.sendMessage({
                            message: [{
                                functionResponse: {
                                    name: call.name,
                                    id: call.id,
                                    response: { result: "Market sentiment is currently MIXED." }
                                }
                            }]
                         });
                         if (marketResponse.text) addToChat(marketResponse.text, Sender.AI);
                        break;
                }

                if (proposal) {
                    setPendingProposal(proposal);
                    addToChat("I've formulated a strategy for this account.", Sender.AI, call.name);
                } else if (!proposal && result.text && call.name !== 'analyze_market_sentiment') {
                     addToChat(result.text, Sender.AI);
                }
            } else {
                if (result.text) addToChat(result.text, Sender.AI);
            }

        } catch (error) {
            console.error("Gemini Error:", error);
            addToChat("Error connecting to AI.", Sender.SYSTEM);
        } finally {
            setIsTyping(false);
        }
    };

    const handleProposalAction = async (proposal: AIProposal, approved: boolean) => {
        setPendingProposal(null);
        setIsTyping(true);
        let executionResult = "Rejected.";
        let systemMsg = "Proposal rejected.";
        
        try {
            if (approved) {
                if (proposal.type === 'CREATE_PORTFOLIO') {
                    createNewStrategy(proposal.details.strategyName, proposal.details.groups);
                    systemMsg = "✅ Portfolio Created for " + activeAccount?.name;
                    executionResult = "Success. Portfolio created.";
                } else if (proposal.type === 'ADD_SLICE') {
                    addTickerToGroup(proposal.details.groupName, proposal.details.symbol, proposal.details.allocation);
                    systemMsg = "✅ Ticker Added to " + activeAccount?.name;
                    executionResult = "Success. Ticker added.";
                } else if (proposal.type === 'REBALANCE') {
                    performRebalance();
                    systemMsg = "✅ Portfolio Rebalanced";
                    executionResult = "Success. Portfolio values reset to targets.";
                }
            }

            addToChat(systemMsg, Sender.SYSTEM);

            if (chatSessionRef.current) {
                const response = await chatSessionRef.current.sendMessage({
                    message: [{
                        functionResponse: {
                            name: proposal.toolName,
                            response: { result: executionResult },
                            id: proposal.id
                        }
                    }]
                });
                if (response.text) addToChat(response.text, Sender.AI);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setIsTyping(false);
        }
    };

    return (
        <div className="flex h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30">
            {/* Sidebar - Institutions & Accounts */}
            <div className="w-64 flex flex-col bg-slate-900 border-r border-slate-800 z-10">
                <div className="p-6 border-b border-slate-800 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                        <Activity className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-bold text-lg tracking-tight">StrataMind</span>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                    {/* Global Summary Item */}
                    <div className="px-2">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Total Net Worth</p>
                        <div className="text-2xl font-mono font-bold text-white">${globalNetWorth.toLocaleString()}</div>
                    </div>

                    {/* Institutions List */}
                    <div className="space-y-4">
                        {institutions.map(inst => {
                            const isCollapsed = collapsedInsts.has(inst.id);
                            const instTotal = inst.accounts.reduce((sum, a) => sum + a.totalValue, 0);
                            
                            return (
                                <div key={inst.id} className="space-y-1">
                                    <div 
                                        className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 cursor-pointer group"
                                        onClick={() => toggleCollapse(inst.id)}
                                    >
                                        <div className="flex items-center gap-2">
                                            {isCollapsed ? <ChevronRight className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                                            <Building2 className="w-4 h-4 text-indigo-400" />
                                            <span className="font-medium text-sm text-slate-200">{inst.name}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-xs text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                                ${(instTotal / 1000).toFixed(1)}k
                                            </span>
                                            <button 
                                                type="button"
                                                onClick={(e) => handleDeleteInstitution(e, inst.id)}
                                                className="p-1 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                            >
                                                <Trash2 className="w-3 h-3" />
                                            </button>
                                        </div>
                                    </div>

                                    {!isCollapsed && (
                                        <div className="pl-4 space-y-1 border-l border-slate-800 ml-4">
                                            {inst.accounts.map(acc => (
                                                <div key={acc.id} className="group/acc relative">
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            setSelectedInstId(inst.id);
                                                            setSelectedAccountId(acc.id);
                                                        }}
                                                        className={`w-full flex items-center justify-between p-2 rounded-md text-sm transition-colors ${
                                                            selectedAccountId === acc.id 
                                                                ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' 
                                                                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                                                        }`}
                                                    >
                                                        <div className="flex items-center gap-2">
                                                            <CreditCard className="w-3 h-3" />
                                                            <span className="truncate max-w-[90px]">{acc.name}</span>
                                                        </div>
                                                        <span className="text-xs opacity-70">${(acc.totalValue / 1000).toFixed(1)}k</span>
                                                    </button>
                                                    <button 
                                                        type="button"
                                                        onClick={(e) => handleDeleteAccount(e, inst.id, acc.id)}
                                                        className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 text-slate-600 hover:text-red-400 opacity-0 group-hover/acc:opacity-100 transition-opacity bg-slate-900 shadow-sm rounded"
                                                    >
                                                        <Trash2 className="w-3 h-3" />
                                                    </button>
                                                </div>
                                            ))}
                                            <button 
                                                type="button"
                                                onClick={(e) => handleAddAccount(e, inst.id)}
                                                className="w-full flex items-center gap-2 p-2 text-xs text-slate-500 hover:text-indigo-400 transition-colors"
                                            >
                                                <PlusCircle className="w-3 h-3" />
                                                Add Account
                                            </button>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="p-4 border-t border-slate-800">
                     <button 
                        type="button"
                        onClick={handleAddInstitution}
                        className="w-full flex items-center justify-center gap-2 p-3 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-sm font-medium transition-colors text-white shadow-lg shadow-indigo-500/20"
                     >
                        <Plus className="w-4 h-4" /> Add Institution
                     </button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
                {activeAccount ? (
                    <>
                        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-900/50 backdrop-blur-sm">
                            <div>
                                <div className="flex items-center gap-2 text-xs text-slate-400 mb-0.5">
                                    <Building2 className="w-3 h-3" />
                                    {activeInstitution?.name} <ChevronRight className="w-3 h-3" /> {activeAccount.type}
                                </div>
                                <h1 className="text-xl font-bold text-white flex items-center gap-3">
                                    {activeAccount.name}
                                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">ACTIVE</span>
                                </h1>
                            </div>
                            <div className="text-right">
                                <div className="text-2xl font-bold font-mono text-white">${activeAccount.totalValue.toLocaleString()}</div>
                                <div className="text-xs text-emerald-400 font-medium flex items-center justify-end gap-1">
                                    <TrendingUp className="w-3 h-3" /> +2.4% Today
                                </div>
                            </div>
                        </header>

                        <main className="flex-1 flex overflow-hidden">
                            <div className="flex-1 p-6 overflow-y-auto space-y-6">
                                {/* Stats Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                                        <p className="text-xs text-slate-400 uppercase">Cash Available</p>
                                        <p className="text-lg font-bold text-white mt-1">${activeAccount.cashBalance.toLocaleString()}</p>
                                    </div>
                                    <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                                        <p className="text-xs text-slate-400 uppercase">Strategy Type</p>
                                        <p className="text-lg font-bold text-indigo-400 mt-1">{activeAccount.root.name}</p>
                                    </div>
                                    <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
                                        <p className="text-xs text-slate-400 uppercase">Holdings Count</p>
                                        <p className="text-lg font-bold text-slate-200 mt-1">
                                            {/* Simple recursive count would go here, simplified for demo */}
                                            {activeAccount.root.children?.length || 0} Sectors
                                        </p>
                                    </div>
                                </div>

                                {/* Pie Visualizer */}
                                <div className="h-[500px]">
                                    <PortfolioVisualizer 
                                        rootSlice={activeAccount.root} 
                                        totalValue={activeAccount.totalValue} 
                                        onAddSlice={handleManualAddSlice}
                                        onRemoveSlice={handleManualRemoveSlice}
                                    />
                                </div>
                            </div>

                            {/* Chat Panel */}
                            <div className="w-[400px] shrink-0 border-l border-slate-800">
                                <ChatPanel 
                                    messages={messages} 
                                    onSendMessage={handleSendMessage}
                                    pendingProposal={pendingProposal}
                                    onApproveProposal={(p) => handleProposalAction(p, true)}
                                    onRejectProposal={(p) => handleProposalAction(p, false)}
                                    isTyping={isTyping}
                                />
                            </div>
                        </main>
                    </>
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-500">
                        <Wallet className="w-16 h-16 mb-4 opacity-20" />
                        <p>Select an account to view details</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default App;