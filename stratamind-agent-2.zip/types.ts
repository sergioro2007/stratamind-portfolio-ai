// Portfolio Data Structures

export enum SliceType {
    GROUP = 'GROUP',
    HOLDING = 'HOLDING'
}

export interface PortfolioSlice {
    id: string;
    parentId: string | null;
    type: SliceType;
    name: string; // "Tech Sector" or "AAPL"
    symbol?: string; // Only for HOLDING
    targetAllocation: number; // Percentage 0-100 (relative to parent)
    currentValue: number; // Mocked current value
    children?: PortfolioSlice[]; // Only for GROUP
}

export interface Account {
    id: string;
    name: string; // e.g. "Roth IRA"
    type: string; // e.g. "Retirement", "Brokerage"
    totalValue: number;
    cashBalance: number;
    root: PortfolioSlice; // The Strategy/Pie
}

export interface Institution {
    id: string;
    name: string; // e.g. "Fidelity", "M1 Finance"
    accounts: Account[];
}

// AI & Chat Types

export enum Sender {
    USER = 'USER',
    AI = 'AI',
    SYSTEM = 'SYSTEM'
}

export interface Message {
    id: string;
    sender: Sender;
    text: string;
    timestamp: Date;
    isTyping?: boolean;
    toolCallId?: string;
    toolName?: string;
    toolArgs?: any;
}

export interface AIProposal {
    id: string;
    type: 'ADD_SLICE' | 'REMOVE_SLICE' | 'REBALANCE' | 'CREATE_PORTFOLIO';
    toolName: string;
    description: string;
    details: any; // Context specific payload
    status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

export interface MarketData {
    symbol: string;
    price: number;
    changePercent: number;
}