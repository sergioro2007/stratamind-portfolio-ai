import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

// Ensure API Key is available
const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

// --- Tool Definitions ---

const createPortfolioTool: FunctionDeclaration = {
    name: 'create_portfolio_structure',
    description: 'Initialize a new portfolio strategy structure for the currently selected account.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            strategyName: { type: Type.STRING, description: 'Name of the root strategy' },
            groups: {
                type: Type.ARRAY,
                description: 'List of initial sectors/groups',
                items: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        allocation: { type: Type.NUMBER, description: 'Target allocation percentage (0-100)' },
                        tickers: { 
                            type: Type.ARRAY, 
                            items: { type: Type.STRING },
                            description: 'Optional list of stock tickers (e.g. ["AAPL", "MSFT"]) to initialize in this group' 
                        }
                    },
                    required: ['name', 'allocation']
                }
            }
        },
        required: ['strategyName', 'groups']
    }
};

const addTickerTool: FunctionDeclaration = {
    name: 'add_ticker_to_group',
    description: 'Add a specific stock ticker to a specific group or the root of the CURRENTLY selected account.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            symbol: { type: Type.STRING, description: 'Stock symbol (e.g., AAPL)' },
            groupName: { type: Type.STRING, description: 'Name of the group to add to (fuzzy match)' },
            allocation: { type: Type.NUMBER, description: 'Target allocation percentage within the group' }
        },
        required: ['symbol', 'allocation']
    }
};

const rebalanceTool: FunctionDeclaration = {
    name: 'rebalance_portfolio',
    description: 'Calculate rebalancing trades to match target allocations for the current account.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            focusGroup: { type: Type.STRING, description: 'Optional: specific group to rebalance, otherwise entire portfolio' }
        }
    }
};

const marketAnalysisTool: FunctionDeclaration = {
    name: 'analyze_market_sentiment',
    description: 'Get current market sentiment for specific sectors to inform decisions.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            sectors: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: 'List of sectors to analyze (e.g., "Tech", "Energy")'
            }
        },
        required: ['sectors']
    }
};

const tools = [createPortfolioTool, addTickerTool, rebalanceTool, marketAnalysisTool];

const SYSTEM_INSTRUCTION = `
You are StrataMind, an expert AI portfolio manager. 
Your goal is to help users build "Pie-based" hierarchical portfolios (similar to M1 Finance).
You can create groups (Pies) and add holdings (Slices) to them.

Context:
The user has multiple accounts across different institutions (e.g., Fidelity, M1).
Changes you propose apply ONLY to the account the user is currently viewing.

Rules:
1. Always ensure allocations within a group sum to 100% ideally, but warn if they don't.
2. When creating a new portfolio, if the user describes a theme (e.g., "Defensive Income"), propose specific tickers (like KO, JNJ, PEP) inside the groups automatically to give them a starting point, unless they ask for an empty structure.
3. Use the provided tools to propose changes. YOU DO NOT EXECUTE CHANGES DIRECTLY. You generate proposals.
4. Be concise, professional, and data-driven.
5. If the user asks for market data, pretend to access real-time data and give a realistic summary (since we are in a demo environment).
`;

export const startChatSession = () => {
    return ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            tools: [{ functionDeclarations: tools }],
        }
    });
};

export { ai };