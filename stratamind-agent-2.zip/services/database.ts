import { Institution, Account, SliceType } from '../types';

const STORAGE_KEY = 'stratamind_db_v1';

export const generateId = (): string => {
    return 'id-' + Math.random().toString(36).substring(2, 9) + '-' + Date.now().toString(36);
};

// --- INITIAL SEED DATA ---
const SEED_DATA: Institution[] = [
    {
        id: 'inst-1',
        name: 'Fidelity',
        accounts: [
            {
                id: 'acc-1',
                name: 'Retirement 401k',
                type: 'Retirement',
                totalValue: 150000,
                cashBalance: 2000,
                root: {
                    id: 'root-fidelity-1',
                    parentId: null,
                    type: SliceType.GROUP,
                    name: 'Core 401k Strategy',
                    targetAllocation: 100,
                    currentValue: 148000,
                    children: [
                        {
                            id: 'g-f1',
                            parentId: 'root-fidelity-1',
                            type: SliceType.GROUP,
                            name: 'US Equities',
                            targetAllocation: 70,
                            currentValue: 103600,
                            children: [
                                { id: 'h-f1', parentId: 'g-f1', type: SliceType.HOLDING, name: 'Vanguard Total Stock', symbol: 'VTI', targetAllocation: 100, currentValue: 103600 }
                            ]
                        },
                        {
                            id: 'g-f2',
                            parentId: 'root-fidelity-1',
                            type: SliceType.GROUP,
                            name: 'Bonds',
                            targetAllocation: 30,
                            currentValue: 44400,
                            children: [
                                { id: 'h-f2', parentId: 'g-f2', type: SliceType.HOLDING, name: 'US Bond ETF', symbol: 'BND', targetAllocation: 100, currentValue: 44400 }
                            ]
                        }
                    ]
                }
            },
            {
                id: 'acc-2',
                name: 'Individual Brokerage',
                type: 'Brokerage',
                totalValue: 25000,
                cashBalance: 5000,
                root: {
                    id: 'root-fidelity-2',
                    parentId: null,
                    type: SliceType.GROUP,
                    name: 'Play Money',
                    targetAllocation: 100,
                    currentValue: 20000,
                    children: [] 
                }
            }
        ]
    },
    {
        id: 'inst-2',
        name: 'M1 Financial',
        accounts: [
            {
                id: 'acc-3',
                name: 'Tech Growth Pie',
                type: 'Taxable',
                totalValue: 50000,
                cashBalance: 500,
                root: {
                    id: 'root-m1-1',
                    parentId: null,
                    type: SliceType.GROUP,
                    name: 'Aggressive Tech',
                    targetAllocation: 100,
                    currentValue: 49500,
                    children: [
                        {
                            id: 'g-m1',
                            parentId: 'root-m1-1',
                            type: SliceType.GROUP,
                            name: 'Semiconductors',
                            targetAllocation: 50,
                            currentValue: 24750,
                            children: [
                                { id: 'h-m1', parentId: 'g-m1', type: SliceType.HOLDING, name: 'NVIDIA', symbol: 'NVDA', targetAllocation: 60, currentValue: 14850 },
                                { id: 'h-m2', parentId: 'g-m1', type: SliceType.HOLDING, name: 'AMD', symbol: 'AMD', targetAllocation: 40, currentValue: 9900 }
                            ]
                        },
                        {
                            id: 'g-m2',
                            parentId: 'root-m1-1',
                            type: SliceType.GROUP,
                            name: 'Software',
                            targetAllocation: 50,
                            currentValue: 24750,
                            children: [
                                { id: 'h-m3', parentId: 'g-m2', type: SliceType.HOLDING, name: 'Microsoft', symbol: 'MSFT', targetAllocation: 100, currentValue: 24750 }
                            ]
                        }
                    ]
                }
            }
        ]
    }
];

export const db = {
    load: (): Institution[] => {
        try {
            const data = localStorage.getItem(STORAGE_KEY);
            if (data) {
                return JSON.parse(data);
            }
        } catch (e) {
            console.error("Failed to load DB", e);
        }
        // Return default seed if empty
        return SEED_DATA;
    },

    save: (data: Institution[]) => {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.error("Failed to save DB", e);
        }
    },

    // --- CRUD Helpers ---

    createInstitution: (name: string, allInsts: Institution[]): Institution[] => {
        const newInst: Institution = {
            id: generateId(),
            name,
            accounts: []
        };
        const updated = [...allInsts, newInst];
        db.save(updated);
        return updated;
    },

    deleteInstitution: (id: string, allInsts: Institution[]): Institution[] => {
        const updated = allInsts.filter(i => i.id !== id);
        db.save(updated);
        return updated;
    },

    createAccount: (instId: string, name: string, type: string, allInsts: Institution[]): Institution[] => {
        const updated = allInsts.map(inst => {
            if (inst.id !== instId) return inst;
            const newAcc: Account = {
                id: generateId(),
                name,
                type,
                totalValue: 0,
                cashBalance: 0,
                root: {
                    id: generateId(),
                    parentId: null,
                    type: SliceType.GROUP,
                    name: 'New Strategy',
                    targetAllocation: 100,
                    currentValue: 0,
                    children: []
                }
            };
            return { ...inst, accounts: [...inst.accounts, newAcc] };
        });
        db.save(updated);
        return updated;
    },

    deleteAccount: (instId: string, accId: string, allInsts: Institution[]): Institution[] => {
        const updated = allInsts.map(inst => {
            if (inst.id !== instId) return inst;
            return { ...inst, accounts: inst.accounts.filter(a => a.id !== accId) };
        });
        db.save(updated);
        return updated;
    }
};